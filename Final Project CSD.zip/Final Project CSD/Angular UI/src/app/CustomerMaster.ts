export class CustomerMaster{

    custId!: string;
    custFirstName!: string;
    custLastName!: string;
    address!: string;
    city!: string;
    state!: string;
    contactNo!: number;
    adharCard!: number;
    emailId!: string;
    birthDate!: Date;
    monthlySalary!: number;
    loanType!: string;

}