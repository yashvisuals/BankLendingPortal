
export class LoanApplication{

    loanAppId!: string;
    custId: string | undefined;
    loanAmt: number | undefined;
    noOfYears: number | undefined;
    purpose: string | undefined;
    appStatus: string | undefined;
    typeOfLoan: string | undefined;
    loanAppDate!: Date;
    status: string | undefined;

}