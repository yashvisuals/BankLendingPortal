package com.cognizant.banking.test.main;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;
import com.cognizant.banking.BankingProjectApplication;

	@SpringBootTest(classes = BankingProjectApplication.class)
	public class BankingProjectApplicationTests {	
		@Test
		public void contextLoads() {
		}

	}
	

