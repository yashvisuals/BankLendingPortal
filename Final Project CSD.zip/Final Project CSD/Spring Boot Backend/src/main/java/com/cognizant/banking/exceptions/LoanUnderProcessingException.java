package com.cognizant.banking.exceptions;

public class LoanUnderProcessingException extends RuntimeException{

	private static final long serialVersionUID = 1L;
	
	public LoanUnderProcessingException(String message) {
		super();
	}
}
