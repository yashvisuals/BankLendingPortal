package com.cognizant.banking.exceptions;

public class AgeBarException extends RuntimeException{

	private static final long serialVersionUID = 1L;

	public AgeBarException(String message) {
		
	super(message);
	
	}
}
